const options = {
  valueNames: [ 'name', 'spec', 'days', 'times' ]
};

let userList = new List('doctors', options);